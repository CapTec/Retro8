requirejs(["interpreter/interpreter"], function(Interpreter) {
    var processor = new Interpreter();
});
